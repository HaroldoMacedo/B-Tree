package algorithm.btree;

public interface BTreeKeyFactory {
  public BTreeKey getBTreeKey(int key);
}
